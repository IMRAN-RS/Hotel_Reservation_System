# Hotel-Reservation-System


HOTEL MANAGEMENT SYSTEM
1. Reserve a room 
2. View reservation
3. Get room number
4. Update reservation
5. Delete reservation
0. Exit

CHOOSE ANY OPTION : 1

Please Enter guest details for reservation 

Enter Guest name : Sumit

Enter room number : 125

Enter contact number : 14578

Reservation successfully

HOTEL MANAGEMENT SYSTEM
1. Reserve a room 
2. View reservation
3. Get room number
4. Update reservation
5. Delete reservation
0. Exit

CHOOSE ANY OPTION : 2

![image](https://github.com/Nikhilks14/Hotel-Reservation-System/assets/66267528/342e64b8-7260-4c00-93ed-74534a708a70)

HOTEL MANAGEMENT SYSTEM
1. Reserve a room 
2. View reservation
3. Get room number
4. Update reservation
5. Delete reservation
0. Exit

CHOOSE ANY OPTION : 3

Enter reservation ID : 8

Enter Name : Sumit


Reservation ID : 8

Guest name : Sumit

Room number : 125


HOTEL MANAGEMENT SYSTEM
1. Reserve a room 
2. View reservation
3. Get room number
4. Update reservation
5. Delete reservation
0. Exit

CHOOSE ANY OPTION : 4

Enter reservation ID to Update : 8
 Enter new guest name :Sumit 
 Enter new room number : 1006
 Enter new contact number :45789
 Successfully Updated

HOTEL MANAGEMENT SYSTEM
1. Reserve a room 
2. View reservation
3. Get room number
4. Update reservation
5. Delete reservation
0. Exit

CHOOSE ANY OPTION : 0

Exiting System.....
ThankYou For Using Hotel Reservation System!!!

Process finished with exit code 0
